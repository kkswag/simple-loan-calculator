package th.ac.su.natnicha.simpleloancalculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnCal : Button= findViewById<Button>(R.id.btnCal)
        btnCal.setOnClickListener {
            val intent = Intent(this, result :: class.java)
            startActivity(intent)

        }
        val btnBarcode : Button= findViewById<Button>(R.id.btnBarcode)
        btnBarcode.setOnClickListener {
            val intent = Intent(this, list_barcode :: class.java)
            startActivity(intent)

        }
    }
}