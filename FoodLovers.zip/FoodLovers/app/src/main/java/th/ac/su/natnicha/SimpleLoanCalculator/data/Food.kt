package th.ac.su.natnicha.`Simple Loan Calculator`.data

data class Food(
    val image:String,
    val Food:String,
    val Store:String,
    val price:String,
    val star:Int,
    val Foodinfo:String
)